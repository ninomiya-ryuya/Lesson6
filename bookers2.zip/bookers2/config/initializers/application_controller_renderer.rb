# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '99b3f8175b06931f5320e01a2e5cbbab8ff450ad20d522ad822c491869a0c3f02d8c08c968ea7e2951cf2347acddb2d6c1ca645e1426178dfc725e57af68f1e0'